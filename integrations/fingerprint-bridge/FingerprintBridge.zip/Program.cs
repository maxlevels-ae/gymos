using FingerprintBridge.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<ZkService>();

var app = builder.Build();

var zk = app.Services.GetRequiredService<ZkService>();
zk.Init();

app.MapGet("/device/status", () => Results.Ok(zk.GetStatus()));

app.MapPost("/capture", () =>
{
    var result = zk.Capture();

    if (result == null)
    {
        return Results.BadRequest(new
        {
            success = false,
            error = zk.GetLastError()
        });
    }

    return Results.Ok(new
    {
        success = true,
        template = result.TemplateB64,
        quality = result.Quality,
        width = result.Width,
        height = result.Height,
        capturedAtUtc = result.CapturedAtUtc,
    });
});

app.MapPost("/merge", (MergeRequest req) =>
{
    if (string.IsNullOrWhiteSpace(req.Template1B64) || string.IsNullOrWhiteSpace(req.Template2B64) || string.IsNullOrWhiteSpace(req.Template3B64))
    {
        return Results.BadRequest(new { success = false, error = "Three templates are required" });
    }

    var result = zk.MergeTemplates(req.Template1B64, req.Template2B64, req.Template3B64);
    return result.Success ? Results.Ok(result) : Results.BadRequest(result);
});

app.MapPost("/identify", (StartIdentifyRequest req) =>
{
    if (string.IsNullOrWhiteSpace(req.ProbeTemplateB64))
    {
        return Results.BadRequest(new { success = false, error = "probeTemplateB64 is required" });
    }

    var result = zk.Identify(req.ProbeTemplateB64, req.Candidates);
    return result.Success ? Results.Ok(result) : Results.BadRequest(result);
});

app.MapPost("/match", (MatchRequest req) =>
{
    if (string.IsNullOrWhiteSpace(req.Template1B64) || string.IsNullOrWhiteSpace(req.Template2B64))
    {
        return Results.BadRequest(new { success = false, error = "Two templates are required" });
    }

    var result = zk.Match(req.Template1B64, req.Template2B64);
    return result.Success ? Results.Ok(result) : Results.BadRequest(result);
});

app.Run("http://localhost:7001");
