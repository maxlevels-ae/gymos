namespace FingerprintBridge.Models;

public class CandidateTemplate
{
    public string MemberId { get; set; } = string.Empty;
    public string TemplateB64 { get; set; } = string.Empty;
}

public class StartIdentifyRequest
{
    public string ProbeTemplateB64 { get; set; } = string.Empty;
    public List<CandidateTemplate> Candidates { get; set; } = new();
}

public class MergeRequest
{
    public string Template1B64 { get; set; } = string.Empty;
    public string Template2B64 { get; set; } = string.Empty;
    public string Template3B64 { get; set; } = string.Empty;
}

public class MatchRequest
{
    public string Template1B64 { get; set; } = string.Empty;
    public string Template2B64 { get; set; } = string.Empty;
}

public class CaptureResult
{
    public bool Success { get; set; }
    public string TemplateB64 { get; set; } = string.Empty;
    public int TemplateSize { get; set; }
    public int Quality { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public DateTime CapturedAtUtc { get; set; }
}

public class MergeResult
{
    public bool Success { get; set; }
    public string? TemplateB64 { get; set; }
    public int TemplateSize { get; set; }
    public string? Error { get; set; }

    public static MergeResult Fail(string error) => new()
    {
        Success = false,
        Error = error,
    };
}

public class IdentifyResult
{
    public bool Success { get; set; }
    public bool Matched { get; set; }
    public string? MemberId { get; set; }
    public int MatchIndex { get; set; }
    public int Score { get; set; }
    public string? Error { get; set; }

    public static IdentifyResult Fail(string error) => new()
    {
        Success = false,
        Error = error,
    };
}

public class MatchResult
{
    public bool Success { get; set; }
    public bool Matched { get; set; }
    public int Score { get; set; }
    public string? Error { get; set; }

    public static MatchResult Fail(string error) => new()
    {
        Success = false,
        Error = error,
    };
}
