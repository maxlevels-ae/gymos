namespace FingerprintBridge.Models;

public class IdentifySession
{
    public string SessionId { get; set; } = Guid.NewGuid().ToString("N");
    public string Status { get; set; } = "armed";
    public string? MemberId { get; set; }
    public int Score { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime StartedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime ExpiresAtUtc { get; set; } = DateTime.UtcNow.AddSeconds(60);
}
