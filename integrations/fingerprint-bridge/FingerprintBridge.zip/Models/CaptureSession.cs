namespace FingerprintBridge.Models;

public class CaptureSession
{
    public string SessionId { get; set; } = Guid.NewGuid().ToString("N");
    public string MemberId { get; set; } = string.Empty;
    public int SampleIndex { get; set; }
    public string Status { get; set; } = "armed";
    public int Quality { get; set; }
    public string? TemplateB64 { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime StartedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime ExpiresAtUtc { get; set; } = DateTime.UtcNow.AddSeconds(60);
}
