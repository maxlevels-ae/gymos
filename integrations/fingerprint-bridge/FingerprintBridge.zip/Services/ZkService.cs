using System.Text;
using libzkfpcsharp;
using FingerprintBridge.Models;

public class ZkService
{
    private IntPtr devHandle = IntPtr.Zero;
    private IntPtr dbHandle = IntPtr.Zero;

    private byte[]? imgBuffer;
    private byte[]? templateBuffer;

    private int width = 0;
    private int height = 0;

    private bool initialized = false;
    private string? lastError;

    public bool Init()
    {
        try
        {
            int ret = zkfp2.Init();
            if (ret != zkfp.ZKFP_ERR_OK)
            {
                lastError = $"zkfp2.Init failed: {ret}";
                initialized = false;
                return false;
            }

            int count = zkfp2.GetDeviceCount();
            if (count <= 0)
            {
                lastError = "No fingerprint device found";
                initialized = false;
                return false;
            }

            devHandle = zkfp2.OpenDevice(0);
            if (devHandle == IntPtr.Zero)
            {
                lastError = "OpenDevice failed";
                initialized = false;
                return false;
            }

            dbHandle = zkfp2.DBInit();
            if (dbHandle == IntPtr.Zero)
            {
                lastError = "DBInit failed";
                initialized = false;
                return false;
            }

            byte[] param = new byte[4];
            int size = 4;

            zkfp2.GetParameters(devHandle, 1, param, ref size);
            width = BitConverter.ToInt32(param, 0);

            size = 4;
            zkfp2.GetParameters(devHandle, 2, param, ref size);
            height = BitConverter.ToInt32(param, 0);

            imgBuffer = new byte[Math.Max(width * height, 0)];
            templateBuffer = new byte[2048];

            lastError = null;
            initialized = true;
            return true;
        }
        catch (Exception ex)
        {
            lastError = ex.Message;
            initialized = false;
            return false;
        }
    }

    public object GetStatus()
    {
        return new
        {
            connected = initialized,
            deviceIndex = 0,
            sdkInitialized = initialized,
            imageWidth = width,
            imageHeight = height,
            error = lastError
        };
    }

    public CaptureResult? Capture()
    {
        if (!EnsureReady())
        {
            return null;
        }

        int size = templateBuffer!.Length;
        int ret = zkfp2.AcquireFingerprint(devHandle, imgBuffer!, templateBuffer!, ref size);

        if (ret == zkfp.ZKFP_ERR_OK)
        {
            var templateBytes = new byte[size];
            Buffer.BlockCopy(templateBuffer!, 0, templateBytes, 0, size);

            var quality = EstimateImageQuality(imgBuffer!, width, height);
            lastError = null;

            return new CaptureResult
            {
                Success = true,
                TemplateB64 = Convert.ToBase64String(templateBytes),
                TemplateSize = size,
                Quality = quality,
                Width = width,
                Height = height,
                CapturedAtUtc = DateTime.UtcNow,
            };
        }

        lastError = $"AcquireFingerprint failed: {ret}";
        return null;
    }

    public MergeResult MergeTemplates(string template1B64, string template2B64, string template3B64)
    {
        if (!EnsureReady())
        {
            return MergeResult.Fail(lastError ?? "Bridge is not initialized");
        }

        try
        {
            var t1 = Convert.FromBase64String(template1B64);
            var t2 = Convert.FromBase64String(template2B64);
            var t3 = Convert.FromBase64String(template3B64);

            var regTemplate = new byte[2048];
            int regSize = regTemplate.Length;

            int ret = zkfp2.DBMerge(dbHandle, t1, t2, t3, regTemplate, ref regSize);
            if (ret != zkfp.ZKFP_ERR_OK)
            {
                lastError = $"DBMerge failed: {ret}";
                return MergeResult.Fail(lastError);
            }

            var merged = new byte[regSize];
            Buffer.BlockCopy(regTemplate, 0, merged, 0, regSize);

            lastError = null;
            return new MergeResult
            {
                Success = true,
                TemplateB64 = Convert.ToBase64String(merged),
                TemplateSize = regSize,
            };
        }
        catch (FormatException)
        {
            lastError = "One or more templates are not valid base64";
            return MergeResult.Fail(lastError);
        }
        catch (Exception ex)
        {
            lastError = ex.Message;
            return MergeResult.Fail(lastError);
        }
    }

    public IdentifyResult Identify(string probeTemplateB64, List<CandidateTemplate> candidates)
    {
        if (!EnsureReady())
        {
            return IdentifyResult.Fail(lastError ?? "Bridge is not initialized");
        }

        if (candidates == null || candidates.Count == 0)
        {
            return IdentifyResult.Fail("Candidates are required");
        }

        try
        {
            zkfp2.DBFree(dbHandle);
            dbHandle = zkfp2.DBInit();
            if (dbHandle == IntPtr.Zero)
            {
                lastError = "DBInit failed during identify";
                return IdentifyResult.Fail(lastError);
            }

            var indexToMember = new Dictionary<int, string>();
            int dbIndex = 1;

            foreach (var c in candidates)
            {
                if (string.IsNullOrWhiteSpace(c.MemberId) || string.IsNullOrWhiteSpace(c.TemplateB64))
                {
                    continue;
                }

                byte[] candidateBytes;
                try
                {
                    candidateBytes = Convert.FromBase64String(c.TemplateB64);
                }
                catch
                {
                    continue;
                }

                int addRet = zkfp2.DBAdd(dbHandle, dbIndex, candidateBytes);
                if (addRet == zkfp.ZKFP_ERR_OK)
                {
                    indexToMember[dbIndex] = c.MemberId;
                    dbIndex++;
                }
            }

            if (indexToMember.Count == 0)
            {
                lastError = "No valid candidate templates were added to DB";
                return IdentifyResult.Fail(lastError);
            }

            var probeBytes = Convert.FromBase64String(probeTemplateB64);
            int matchedId = 0;
            int score = 0;
            int ret = zkfp2.DBIdentify(dbHandle, probeBytes, ref matchedId, ref score);

            if (ret == zkfp.ZKFP_ERR_OK && indexToMember.TryGetValue(matchedId, out var memberId))
            {
                lastError = null;
                return new IdentifyResult
                {
                    Success = true,
                    Matched = true,
                    MemberId = memberId,
                    MatchIndex = matchedId,
                    Score = score,
                };
            }

            lastError = $"DBIdentify failed: {ret}";
            return new IdentifyResult
            {
                Success = true,
                Matched = false,
                Score = score,
                Error = lastError,
            };
        }
        catch (FormatException)
        {
            lastError = "Probe template is not valid base64";
            return IdentifyResult.Fail(lastError);
        }
        catch (Exception ex)
        {
            lastError = ex.Message;
            return IdentifyResult.Fail(lastError);
        }
    }

    public MatchResult Match(string template1B64, string template2B64)
    {
        if (!EnsureReady())
        {
            return MatchResult.Fail(lastError ?? "Bridge is not initialized");
        }

        try
        {
            var t1 = Convert.FromBase64String(template1B64);
            var t2 = Convert.FromBase64String(template2B64);

            int score = zkfp2.DBMatch(dbHandle, t1, t2);
            lastError = null;

            return new MatchResult
            {
                Success = true,
                Score = score,
                Matched = score > 0,
            };
        }
        catch (FormatException)
        {
            lastError = "One or more templates are not valid base64";
            return MatchResult.Fail(lastError);
        }
        catch (Exception ex)
        {
            lastError = ex.Message;
            return MatchResult.Fail(lastError);
        }
    }

    public string? GetLastError() => lastError;

    private bool EnsureReady()
    {
        if (initialized && devHandle != IntPtr.Zero && dbHandle != IntPtr.Zero && imgBuffer != null && templateBuffer != null)
        {
            return true;
        }

        lastError = "Fingerprint device is not connected or SDK is not initialized";
        return false;
    }

    private static int EstimateImageQuality(byte[] image, int width, int height)
    {
        if (image == null || image.Length == 0 || width <= 0 || height <= 0)
        {
            return 0;
        }

        double mean = 0;
        for (int i = 0; i < image.Length; i++)
        {
            mean += image[i];
        }
        mean /= image.Length;

        double variance = 0;
        for (int i = 0; i < image.Length; i++)
        {
            double d = image[i] - mean;
            variance += d * d;
        }
        variance /= image.Length;

        long gradientSum = 0;
        int samples = 0;
        for (int y = 1; y < height - 1; y++)
        {
            int row = y * width;
            for (int x = 1; x < width - 1; x++)
            {
                int idx = row + x;
                int gx = Math.Abs(image[idx + 1] - image[idx - 1]);
                int gy = Math.Abs(image[idx + width] - image[idx - width]);
                gradientSum += gx + gy;
                samples++;
            }
        }

        double gradientAvg = samples > 0 ? (double)gradientSum / samples : 0;

        // Heuristic normalization, not SDK-native quality.
        double varianceScore = Math.Min(variance / 120.0, 50.0);
        double gradientScore = Math.Min(gradientAvg / 2.0, 50.0);
        int score = (int)Math.Round(Math.Clamp(varianceScore + gradientScore, 0, 100));

        return score;
    }
}
